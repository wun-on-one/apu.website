export interface Sport {
  id: string;
  name: string;
  category: 'Outdoor' | 'Indoor' | 'Competitive' | 'Workshop';
  image: string;
  description: string;
  link: string;
}

export interface ScheduleItem {
  id: string;
  time: string;
  event: string;
  location: string;
  day: number;
  category: 'Ceremony' | 'Tournament' | 'Workshop' | 'Finals';
}

export interface NewsPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  content: string;
  image: string;
  category: 'Announcement' | 'Achievement' | 'Sponsorship' | 'Event';
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: 'Registration' | 'Schedule' | 'Rules' | 'Prizes' | 'Venue';
}

export interface Sponsor {
  id: string;
  name: string;
  logo: string;
  tier: 'Platinum' | 'Gold' | 'Silver';
}