import React from 'react';
import { Sport, ScheduleItem, NewsPost, FAQ, Sponsor } from './types';

export const COLORS = {
  background: '#0B0F14',
  primary: '#C6FF00', // Neon Green
  textPrimary: '#FFFFFF',
  textSecondary: '#B0B0B0'
};

export const NAV_LINKS = [
  { name: 'Home', path: '/' },
  { name: 'About', path: '/about' },
  { name: 'Sports', path: '/sports' },
  { name: 'Schedule', path: '/schedule' },
  { name: 'Registration', path: '/registration' },
  { name: 'Gallery', path: '/gallery' },
  { name: 'News', path: '/news' },
  { name: 'FAQ', path: '/faq' },
  { name: 'Contact', path: '/contact' }
];

export const SPORTS_DATA: Sport[] = [
  { id: '1', name: 'Football League', category: 'Outdoor', image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80&w=800', description: 'Experience the ultimate clash of titans on the pitch.', link: '/football' },
  { id: '2', name: 'Basketball (Trident Games)', category: 'Indoor', image: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=800', description: 'UBL 2024 Dominators. Join the legacy of the Trident Games winners.', link: '/basketball' },
  { id: '3', name: 'Taekwondo & Martial Arts', category: 'Competitive', image: 'https://images.unsplash.com/photo-1552072805-2a9039d00e57?auto=format&fit=crop&q=80&w=800', description: 'Karate, Judo, and Taekwondo. Discipline and power on the tatami.', link: '/taekwondo' },
  { id: '4', name: 'Badminton Club', category: 'Indoor', image: 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&q=80&w=800', description: 'Fast-paced smashes and strategic net play at TPM courts.', link: '/badminton' },
  { id: '5', name: 'Esports Club', category: 'Competitive', image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800', description: 'Active mobile and console gaming. Compete in the digital arena.', link: '/esports' },
  { id: '6', name: 'Volleyball (Men/Women)', category: 'Indoor', image: 'https://images.unsplash.com/photo-1592656670411-591e9c174695?auto=format&fit=crop&q=80&w=800', description: 'MASISWA 2025 Second Runner-up. High-flying action on the court.', link: '/volleyball' },
  { id: '7', name: 'Futsal (Women/Men)', category: 'Indoor', image: 'https://images.unsplash.com/photo-1518604666860-9ed391f76460?auto=format&fit=crop&q=80&w=800', description: 'Fast-paced indoor football at the TPM complex.', link: '/futsal' },
  { id: '8', name: 'Frisbee (Team Pixel)', category: 'Outdoor', image: 'https://images.unsplash.com/photo-1551516594-56cb78394645?auto=format&fit=crop&q=80&w=800', description: '2024 Nottingham Battle Royale Winners. Ultimate precision and teamwork.', link: '/frisbee' },
  { id: '9', name: 'Rugby (APU Tigers)', category: 'Outdoor', image: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=800', description: 'Strength, speed, and strategy with the APU Tigers.', link: '/rugby' },
  { id: '10', name: 'Dodgeball & Table Tennis', category: 'Indoor', image: 'https://images.unsplash.com/photo-1534158914592-062992fbe900?auto=format&fit=crop&q=80&w=800', description: 'Reflexes and agility in these high-energy indoor sports.', link: '/sports' },
  { id: '11', name: 'Muay Thai & Wushu', category: 'Competitive', image: 'https://images.unsplash.com/photo-1599058917233-57c0e621c400?auto=format&fit=crop&q=80&w=800', description: 'Traditional and modern combat arts. Medals won in 2022-2025.', link: '/taekwondo' },
  { id: '12', name: 'Swimming & Water Sports', category: 'Outdoor', image: 'https://images.unsplash.com/photo-1530549387074-d56a99e14513?auto=format&fit=crop&q=80&w=800', description: 'Dive into the TPM swimming pool for competitive laps.', link: '/sports' },
  { id: '13', name: 'PaceMakers Running Club', category: 'Outdoor', image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&q=80&w=800', description: 'Join the community of runners for endurance and health.', link: '/sports' },
  { id: '14', name: 'Cheerleading & Billiards', category: 'Workshop', image: 'https://images.unsplash.com/photo-1511943044981-03fdc4a01e47?auto=format&fit=crop&q=80&w=800', description: 'Spirit, precision, and focus across diverse recreational clubs.', link: '/sports' }
];

export const SCHEDULE_DATA: ScheduleItem[] = [
  // Day 1
  { id: 's1', day: 1, time: '09:00 AM', event: 'Opening Ceremony', location: 'Main Arena', category: 'Ceremony' },
  { id: 's2', day: 1, time: '10:30 AM', event: 'Football Qualifiers', location: 'Outdoor Field', category: 'Tournament' },
  { id: 's3', day: 1, time: '11:00 AM', event: 'Basketball Trident Games', location: 'Indoor Court', category: 'Tournament' },
  { id: 's4', day: 1, time: '01:00 PM', event: 'E-Sports Group Stage', location: 'Tech Lab 1', category: 'Tournament' },
  { id: 's5', day: 1, time: '02:30 PM', event: 'Volleyball Prelims', location: 'Indoor Court', category: 'Tournament' },
  { id: 's6', day: 1, time: '04:00 PM', event: 'Martial Arts Workshop', location: 'Multi-Purpose Hall', category: 'Workshop' },
  
  // Day 2
  { id: 's7', day: 2, time: '09:00 AM', event: 'Badminton Quarter Finals', location: 'TPM Courts', category: 'Tournament' },
  { id: 's8', day: 2, time: '10:30 AM', event: 'Futsal Women\'s League', location: 'Outdoor Court', category: 'Tournament' },
  { id: 's9', day: 2, time: '01:00 PM', event: 'Frisbee Team Pixel Demo', location: 'Outdoor Field', category: 'Workshop' },
  { id: 's10', day: 2, time: '02:30 PM', event: 'Basketball Semi-Finals', location: 'Indoor Court', category: 'Tournament' },
  { id: 's11', day: 2, time: '04:00 PM', event: 'Rugby APU Tigers Match', location: 'Outdoor Field', category: 'Tournament' },
  { id: 's12', day: 2, time: '05:30 PM', event: 'E-Sports Semi-Finals', location: 'Tech Lab 1', category: 'Tournament' },

  // Day 3
  { id: 's13', day: 3, time: '08:00 AM', event: 'PaceMakers Morning Run', location: 'Main Entrance', category: 'Workshop' },
  { id: 's14', day: 3, time: '10:00 AM', event: 'Badminton Finals', location: 'TPM Courts', category: 'Finals' },
  { id: 's15', day: 3, time: '12:00 PM', event: 'Basketball Grand Finals', location: 'Indoor Court', category: 'Finals' },
  { id: 's16', day: 3, time: '02:00 PM', event: 'Football Grand Finals', location: 'Outdoor Field', category: 'Finals' },
  { id: 's17', day: 3, time: '04:00 PM', event: 'E-Sports Grand Finals', location: 'Main Arena', category: 'Finals' },
  { id: 's18', day: 3, time: '06:00 PM', event: 'Closing & Awards Ceremony', location: 'Main Arena', category: 'Ceremony' }
];

export const NEWS_DATA: NewsPost[] = [
  { 
    id: 'n1', 
    title: 'New Sponsors Join APU Sport 2026', 
    date: 'Oct 12, 2025', 
    excerpt: 'Global tech giants have confirmed their partnership for the upcoming carnival...', 
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800', 
    content: 'We are thrilled to welcome several new partners to the APU Sport family. Their contribution will enhance the prizes and facilities for all participants. This year, we are focusing on integrating smart sports technology into our events.',
    category: 'Sponsorship'
  },
  { 
    id: 'n2', 
    title: 'Early Bird Registration Extended', 
    date: 'Oct 08, 2025', 
    excerpt: 'Due to overwhelming response, the 15% discount for early registrations is now valid until...', 
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800', 
    content: 'The committee has decided to extend the registration window to allow more students to form teams and prepare for the competition. Don\'t miss this chance to be part of the biggest sports event of the year!',
    category: 'Announcement'
  },
  { 
    id: 'n3', 
    title: 'APU Tigers Rugby Team Secures New Kit Sponsor', 
    date: 'Oct 05, 2025', 
    excerpt: 'The Tigers are ready to roar in their new high-performance gear provided by...', 
    image: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=800', 
    content: 'The APU Tigers Rugby team has officially signed a kit sponsorship deal with a leading sports apparel brand. The new kits feature advanced moisture-wicking technology to keep our players at their peak performance.',
    category: 'Sponsorship'
  },
  { 
    id: 'n4', 
    title: 'Basketball Trident Games: Final Teams Announced', 
    date: 'Oct 01, 2025', 
    excerpt: 'The selection process is over. Meet the elite teams competing for the Trident Trophy...', 
    image: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=800', 
    content: 'After weeks of intense trials, the final teams for the Basketball Trident Games have been selected. This year\'s lineup features some of the most talented players in APU history.',
    category: 'Event'
  },
  { 
    id: 'n5', 
    title: 'E-Sports Arena Setup Begins at Tech Lab 1', 
    date: 'Sep 28, 2025', 
    excerpt: 'The digital battlefield is taking shape with high-end gaming rigs and professional streaming setups...', 
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800', 
    content: 'Tech Lab 1 is being transformed into a world-class E-Sports arena. With ultra-fast fiber connectivity and top-tier gaming hardware, we are ready to host the most competitive gaming tournament yet.',
    category: 'Event'
  },
  { 
    id: 'n6', 
    title: 'Volunteer Recruitment Now Open', 
    date: 'Sep 25, 2025', 
    excerpt: 'Be the backbone of the carnival. Gain experience in event management and sports coordination...', 
    image: 'https://images.unsplash.com/photo-1559027615-cd2671d19d81?auto=format&fit=crop&q=80&w=800', 
    content: 'We are looking for passionate individuals to join our volunteer team. Roles include event marshals, media coordinators, and athlete liaisons. Join us and help make APU Sport 2026 a success!',
    category: 'Announcement'
  }
];

export const FAQS: FAQ[] = [
  { id: 'f1', category: 'Registration', question: 'Who can participate in APU Sport 2026?', answer: 'All current APU students, alumni, and invited staff members can register for the competitive events.' },
  { id: 'f2', category: 'Registration', question: 'Are there any registration fees?', answer: 'Most workshops are free. Competitive league events require a small commitment fee per team (ranging from $10-$50) to cover logistical costs.' },
  { id: 'f3', category: 'Schedule', question: 'Can I register for multiple sports?', answer: 'Yes, as long as the schedules do not overlap. We highly recommend checking the interactive timetable on our Schedule page before finalizing multiple registrations.' },
  { id: 'f4', category: 'Rules', question: 'What is the dress code for the events?', answer: 'Participants must wear proper sports attire. For specific sports like Football or Taekwondo, specialized gear (shin pads, chest guards) is mandatory.' },
  { id: 'f5', category: 'Prizes', question: 'What prizes are available for winners?', answer: 'Winners receive cash prizes (up to $5,000 for team sports), medals, and certificates of excellence. Some sponsors also provide high-tech gadgets for top performers.' },
  { id: 'f6', category: 'Venue', question: 'Where is the main arena located?', answer: 'The carnival takes place at the APU Campus in Technology Park Malaysia. Main events are held at the Sports Center Level 4 and the Outdoor Field.' }
];

