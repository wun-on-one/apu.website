import React from 'react';
import { Link } from 'react-router-dom';

const Rugby: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="relative h-[50vh] rounded-[50px] overflow-hidden group">
        <img src="https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=1600" className="w-full h-full object-cover" alt="Rugby Hero" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F14] via-transparent to-transparent z-20"></div>
        <div className="absolute bottom-12 left-12 z-30">
          <h1 className="text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter text-white">RUGBY</h1>
          <p className="text-[#C6FF00] font-bold tracking-widest text-lg">APU TIGERS - STRENGTH AND HONOR</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-[#12181f] p-10 rounded-3xl border border-gray-800">
          <h2 className="text-2xl font-black mb-6 text-[#C6FF00]">APU TIGERS</h2>
          <p className="text-gray-400 mb-6 font-medium">The APU Tigers represent the pinnacle of physical endurance and strategic teamwork. Competing in both 7s and 15s formats, the Tigers are a force to be reckoned with.</p>
          <ul className="space-y-3 text-sm text-gray-500">
            <li>• Intense physical conditioning</li>
            <li>• Strategic match analysis</li>
            <li>• Strong brotherhood and team spirit</li>
            <li>• Participation in MASISWA and local leagues</li>
          </ul>
        </div>
        <div className="bg-[#12181f] p-10 rounded-3xl border border-gray-800 flex flex-col justify-center items-center text-center">
          <h3 className="text-xl font-black mb-4">UNLEASH THE TIGER</h3>
          <p className="text-gray-400 mb-8">Test your limits with the APU Tigers Rugby Club.</p>
          <Link to="/registration" className="px-10 py-4 bg-[#C6FF00] text-black font-black rounded-full hover:scale-105 transition-transform uppercase tracking-widest text-sm">
            JOIN THE TIGERS
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Rugby;
