
import React from 'react';
import { Link } from 'react-router-dom';

const Basketball: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="relative h-[50vh] rounded-[50px] overflow-hidden group">
        <img src="https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=1600" className="w-full h-full object-cover" alt="Basketball Hero" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F14] via-transparent to-transparent z-20"></div>
        <div className="absolute bottom-12 left-12 z-30">
          <h1 className="text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter text-white">BASKETBALL CUP</h1>
          <p className="text-[#C6FF00] font-bold tracking-widest text-lg">3v3 AND 5v5 CATEGORIES</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-[#12181f] p-10 rounded-3xl border border-gray-800 relative overflow-hidden group">
          <div className="relative z-20">
            <h2 className="text-2xl font-black mb-6 text-[#C6FF00]">5v5 TOURNAMENT</h2>
            <p className="text-gray-400 mb-6 italic">"The full court pressure experience."</p>
            <ul className="space-y-3 text-sm text-gray-500 mb-8">
              <li>• Standard FIBA rules apply</li>
              <li>• 4 Quarters of 10 minutes</li>
              <li>• Open to all faculty teams</li>
              <li>• Guaranteed at least 3 matches</li>
            </ul>
            <Link to="/registration" className="text-[#C6FF00] font-bold hover:underline">Register for 5v5 →</Link>
          </div>
        </div>
        <div className="bg-[#12181f] p-10 rounded-3xl border border-gray-800 relative overflow-hidden group">
          <div className="relative z-20">
            <h2 className="text-2xl font-black mb-6 text-[#C6FF00]">3v3 STREET SERIES</h2>
            <p className="text-gray-400 mb-6 italic">"Fast, gritty, and high intensity."</p>
            <ul className="space-y-3 text-sm text-gray-500 mb-8">
              <li>• Half-court action</li>
              <li>• First to 21 points or 10 mins</li>
              <li>• Team of 4 (1 sub)</li>
              <li>• Open gender categories</li>
            </ul>
            <Link to="/registration" className="text-[#C6FF00] font-bold hover:underline">Register for 3v3 →</Link>
          </div>
        </div>
      </div>

      <section>
        <h2 className="text-3xl font-black mb-12 uppercase text-white tracking-tighter">Tournament Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => (
            <div key={i} className="aspect-square rounded-2xl overflow-hidden grayscale hover:grayscale-0 transition-all cursor-pointer border border-gray-800 relative group">
              <img src={`https://picsum.photos/seed/bb-${i}/400`} className="w-full h-full object-cover" alt="Gallery" />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Basketball;
