
import React from 'react';

const Taekwondo: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-5xl mx-auto space-y-20">
      <div className="text-center">
        <h1 className="text-5xl md:text-7xl font-black mb-6 uppercase tracking-tighter">MARTIAL ARTS<br/><span className="text-[#C6FF00]">ACADEMY</span></h1>
        <p className="text-gray-400 max-w-2xl mx-auto">Discipline, respect, and power. APU's elite martial arts clubs including Taekwondo, Karate Do, Judo, Muay Thai, and Wushu.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="p-8 bg-[#12181f] rounded-3xl border border-gray-800">
            <h3 className="text-xl font-bold mb-4 text-[#C6FF00]">CLUBS & ACHIEVEMENTS</h3>
            <div className="space-y-4">
              <div className="flex flex-col border-b border-gray-800 pb-2">
                <span className="text-white font-bold">Wushu & Karate</span>
                <span className="text-gray-500 text-sm">Multiple medals in 2022/2023/2025 championships.</span>
              </div>
              <div className="flex flex-col border-b border-gray-800 pb-2">
                <span className="text-white font-bold">Judo & Muay Thai</span>
                <span className="text-gray-500 text-sm">Active training sessions at the TPM complex.</span>
              </div>
              <div className="flex flex-col">
                <span className="text-white font-bold">Taekwondo</span>
                <span className="text-gray-500 text-sm">Core discipline with inter-varsity sparring success.</span>
              </div>
            </div>
          </div>

          <div className="p-8 bg-red-900/10 rounded-3xl border border-red-500/30">
            <h3 className="text-xl font-bold mb-4 text-red-500 uppercase tracking-widest">Safety First</h3>
            <p className="text-sm text-gray-400">All participants MUST wear official protective gear. Medical team will be on standby throughout all competitive exhibitions.</p>
          </div>
        </div>
        
        <div className="relative aspect-[3/4] rounded-3xl overflow-hidden group">
          <img src="https://images.unsplash.com/photo-1552072805-2a9039d00e57?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
          <div className="absolute top-8 left-8 bg-[#C6FF00] text-black font-black px-4 py-2 rounded-lg text-xs">ELITE COMBAT</div>
        </div>
      </div>
    </div>
  );
};

export default Taekwondo;
