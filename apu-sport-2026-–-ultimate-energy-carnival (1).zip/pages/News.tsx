
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { NEWS_DATA } from '../constants';

const News: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = ['All', 'Announcement', 'Achievement', 'Sponsorship', 'Event'];

  const filteredNews = useMemo(() => {
    return activeCategory === 'All' 
      ? NEWS_DATA 
      : NEWS_DATA.filter(post => post.category === activeCategory);
  }, [activeCategory]);

  const featuredPost = NEWS_DATA[0];
  const otherPosts = filteredNews.filter(post => post.id !== featuredPost.id || activeCategory !== 'All');

  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-24">
      <div className="text-center space-y-4">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-8xl font-black uppercase tracking-tighter"
        >
          THE <span className="text-[#C6FF00]">BULLETIN</span>
        </motion.h1>
        <p className="text-gray-400 max-w-xl mx-auto">Latest updates, announcements, and stories from the heart of the APU Energy Carnival.</p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-3">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
              activeCategory === cat 
                ? 'bg-[#C6FF00] text-black border-[#C6FF00]' 
                : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Featured Post */}
      {activeCategory === 'All' && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative group rounded-[60px] overflow-hidden border border-gray-800 bg-[#12181f] flex flex-col lg:flex-row h-full min-h-[500px]"
        >
          <div className="lg:w-1/2 h-80 lg:h-auto overflow-hidden">
            <img src={featuredPost.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" alt={featuredPost.title} />
          </div>
          <div className="lg:w-1/2 p-12 md:p-20 flex flex-col justify-center space-y-6">
            <div className="flex items-center gap-4">
              <span className="px-3 py-1 bg-[#C6FF00]/10 text-[#C6FF00] text-[10px] font-black rounded-full border border-[#C6FF00]/20 uppercase tracking-widest">
                {featuredPost.category}
              </span>
              <span className="text-gray-600 text-[10px] font-bold uppercase tracking-widest">{featuredPost.date}</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black leading-none tracking-tighter text-white">{featuredPost.title}</h2>
            <p className="text-gray-400 text-lg leading-relaxed">{featuredPost.excerpt}</p>
            <button 
              onClick={() => setExpandedId(expandedId === featuredPost.id ? null : featuredPost.id)}
              className="w-fit px-8 py-4 bg-[#C6FF00] text-black font-black rounded-2xl hover:scale-105 transition-transform uppercase tracking-widest text-xs"
            >
              {expandedId === featuredPost.id ? 'Read Less' : 'Read Full Story'}
            </button>
            <AnimatePresence>
              {expandedId === featuredPost.id && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <p className="text-gray-300 pt-6 border-t border-gray-800 leading-relaxed">{featuredPost.content}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {otherPosts.map((post, idx) => (
            <motion.div
              key={post.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-[#12181f] rounded-[40px] overflow-hidden border border-gray-800 hover:border-[#C6FF00]/30 transition-all flex flex-col group"
            >
              <div className="h-64 overflow-hidden relative">
                <img src={post.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={post.title} />
                <div className="absolute top-6 left-6 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[9px] text-[#C6FF00] font-black border border-[#C6FF00]/20 uppercase tracking-widest">
                  {post.category}
                </div>
              </div>
              <div className="p-10 flex flex-col flex-grow space-y-4">
                <span className="text-gray-600 text-[10px] font-bold uppercase tracking-widest">{post.date}</span>
                <h3 className="text-2xl font-black leading-tight text-white group-hover:text-[#C6FF00] transition-colors">{post.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed flex-grow">
                  {expandedId === post.id ? post.content : post.excerpt}
                </p>
                <button 
                  onClick={() => setExpandedId(expandedId === post.id ? null : post.id)}
                  className="w-fit text-[10px] font-black text-[#C6FF00] border-b border-[#C6FF00]/30 pb-1 hover:border-[#C6FF00] transition-all uppercase tracking-widest"
                >
                  {expandedId === post.id ? 'Read Less' : 'Read More'}
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Newsletter Signup */}
      <section className="py-20">
        <div className="bg-[#12181f] p-12 md:p-20 rounded-[60px] border border-gray-800 text-center space-y-8 relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#C6FF00]/5 rounded-full blur-3xl"></div>
          <div className="relative z-10 space-y-6">
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">NEVER MISS A BEAT</h2>
            <p className="text-gray-500 max-w-xl mx-auto">Subscribe to our newsletter and get the latest news, event reminders, and exclusive athlete interviews delivered to your inbox.</p>
            <div className="flex flex-col sm:flex-row max-w-lg mx-auto gap-4">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-grow bg-black border border-gray-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#C6FF00] transition-all"
              />
              <button className="px-10 py-4 bg-[#C6FF00] text-black font-black rounded-2xl hover:scale-105 transition-transform uppercase tracking-widest text-xs">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default News;
