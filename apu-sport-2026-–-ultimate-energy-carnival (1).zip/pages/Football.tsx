import React from 'react';
import { Link } from 'react-router-dom';

const Football: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="relative h-[50vh] rounded-[50px] overflow-hidden group">
        <img src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80&w=1600" className="w-full h-full object-cover" />
        
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F14] via-transparent to-transparent z-20"></div>
        <div className="absolute bottom-12 left-12 z-30">
          <h1 className="text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter">FOOTBALL LEAGUE</h1>
          <p className="text-[#C6FF00] font-bold tracking-widest text-lg">THE CLASH OF TITANS</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h2 className="text-2xl font-black mb-6 text-[#C6FF00] uppercase">General Rules</h2>
            <ul className="space-y-4 text-gray-400">
              <li className="flex items-start"><span className="text-[#C6FF00] mr-4 font-bold">01.</span> Standard 11-a-side format with 3 substitutes allowed per match.</li>
              <li className="flex items-start"><span className="text-[#C6FF00] mr-4 font-bold">02.</span> Matches are 60 minutes long (30 mins per half).</li>
              <li className="flex items-start"><span className="text-[#C6FF00] mr-4 font-bold">03.</span> Group stage followed by sudden-death knockout rounds.</li>
              <li className="flex items-start"><span className="text-[#C6FF00] mr-4 font-bold">04.</span> All players must wear shin pads and proper football boots.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-black mb-6 text-[#C6FF00] uppercase">Prize Info</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { title: 'Champions', prize: '$5,000 + Trophy', color: '#C6FF00' },
                { title: 'Runners Up', prize: '$2,500', color: 'white' },
                { title: 'Golden Boot', prize: '$500 + Medal', color: 'gray' }
              ].map((p, idx) => (
                <div key={idx} className="bg-[#12181f] p-6 rounded-2xl border border-gray-800 text-center">
                  <h4 className="text-xs uppercase font-black text-gray-500 mb-2">{p.title}</h4>
                  <p className="text-xl font-black" style={{ color: p.color }}>{p.prize}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-black mb-6 text-[#C6FF00] uppercase">Gameplay Highlights</h2>
            <div className="aspect-video rounded-3xl overflow-hidden bg-gray-900 border border-gray-800">
              <iframe 
                width="100%" height="100%" src="https://www.youtube.com/embed/dQw4w9WgXcQ" 
                title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen
              ></iframe>
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <div className="bg-[#12181f] p-8 rounded-3xl border border-[#C6FF00]/30 shadow-2xl">
            <h3 className="text-xl font-black mb-4">READY TO PLAY?</h3>
            <p className="text-gray-400 text-sm mb-6">Register your team of 15 members (including subs) before the deadline.</p>
            <Link to="/registration" className="block w-full py-4 bg-[#C6FF00] text-black text-center font-black rounded-xl hover:scale-105 transition-transform">
              REGISTER TEAM
            </Link>
          </div>

          <div className="bg-white/5 p-8 rounded-3xl border border-gray-800">
            <h3 className="text-lg font-bold mb-4">TEAM FORMAT</h3>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Min Players</span>
                <span className="text-white font-bold">11</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Max Squad</span>
                <span className="text-white font-bold">18</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Participation Fee</span>
                <span className="text-white font-bold">$50 / Team</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Football;