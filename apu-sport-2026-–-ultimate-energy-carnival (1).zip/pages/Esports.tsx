
import React from 'react';

const Esports: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="relative h-[60vh] rounded-[60px] overflow-hidden border-4 border-[#C6FF00]/20 group">
        <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=1600" className="w-full h-full object-cover" alt="Esports Hero" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F14] via-black/40 to-transparent z-20"></div>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center z-30">
          <h1 className="text-6xl md:text-9xl font-black mb-4 uppercase tracking-tighter neon-glow text-white">E-SPORTS</h1>
          <p className="text-[#C6FF00] font-bold tracking-[0.5em] text-xl">ARENA 2026</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { name: 'VALORANT', type: 'Tactical 5v5', logo: 'https://picsum.photos/seed/val/100' },
          { name: 'LEAGUE', type: 'Strategy MOBA', logo: 'https://picsum.photos/seed/lol/100' },
          { name: 'CS2', type: 'Elite Shooter', logo: 'https://picsum.photos/seed/cs/100' }
        ].map((game, i) => (
          <div key={i} className="bg-[#12181f] p-8 rounded-[40px] border border-gray-800 hover:border-[#C6FF00] transition-all group relative overflow-hidden">
            <div className="relative z-20">
              <img src={game.logo} className="w-16 h-16 rounded-2xl mb-6 grayscale group-hover:grayscale-0 transition-all" alt={game.name} />
              <h3 className="text-2xl font-black mb-2 text-white">{game.name}</h3>
              <p className="text-gray-500 mb-6 uppercase tracking-widest text-xs font-bold">{game.type}</p>
              <div className="flex space-x-2">
                <span className="px-3 py-1 bg-white/5 rounded-full text-[10px] text-gray-400">BRACKET</span>
                <span className="px-3 py-1 bg-white/5 rounded-full text-[10px] text-gray-400">STREAMING</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#12181f] rounded-[50px] p-12 border border-gray-800 relative overflow-hidden group">
        <div className="relative z-20">
          <h2 className="text-3xl font-black mb-8 text-center uppercase tracking-tighter text-white">Tournament Bracket</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center overflow-x-auto pb-8">
            <div className="space-y-4">
              <div className="text-[#C6FF00] font-black">QUARTERS</div>
              <div className="p-4 bg-white/5 rounded-xl border border-gray-800 text-gray-300">Team A vs Team B</div>
              <div className="p-4 bg-white/5 rounded-xl border border-gray-800 text-gray-300">Team C vs Team D</div>
            </div>
            <div className="space-y-4 mt-8">
              <div className="text-[#C6FF00] font-black">SEMIS</div>
              <div className="p-4 bg-white/5 rounded-xl border border-gray-800 text-gray-300">Winner Q1 vs Winner Q2</div>
            </div>
            <div className="space-y-4 mt-16">
              <div className="text-[#C6FF00] font-black text-2xl animate-pulse">FINALS</div>
              <div className="p-8 bg-[#C6FF00] text-black rounded-2xl font-black shadow-[0_0_40px_rgba(198,255,0,0.5)]">ULTIMATE SHOWDOWN</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Esports;
