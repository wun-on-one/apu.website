
import React, { useState } from 'react';

const Registration: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    studentId: '',
    sport: '',
    email: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name) newErrors.name = 'Full name is required';
    if (!formData.studentId) newErrors.studentId = 'Student ID is required';
    else if (!/^TP\d{6}$/.test(formData.studentId)) newErrors.studentId = 'Format: TP123456';
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Invalid email address';
    if (!formData.sport) newErrors.sport = 'Please select a sport';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitted(true);
      setErrors({});
    } else {
      setErrors(validationErrors);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', studentId: '', sport: '', email: '' });
    setErrors({});
    setIsSubmitted(false);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-6">
        <div className="w-20 h-20 bg-[#C6FF00] rounded-full flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(198,255,0,0.5)]">
          <svg className="w-10 h-10 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 className="text-4xl font-black mb-4">REGISTRATION SUCCESSFUL!</h2>
        <p className="text-gray-400 mb-8 text-center max-w-md">Thank you for joining APU Sport 2026. A confirmation email has been sent to {formData.email}.</p>
        <button 
          onClick={resetForm}
          className="px-10 py-4 bg-[#C6FF00] text-black font-black rounded-xl hover:scale-105 transition-transform"
        >
          BACK TO FORM
        </button>
      </div>
    );
  }

  return (
    <div className="px-6 py-20 max-w-3xl mx-auto">
      <div className="mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-black mb-4">ATHLETE REGISTRATION</h1>
        <p className="text-gray-400">Secure your spot in the arena. Limited slots available for each category.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-[#12181f] p-8 md:p-12 rounded-[30px] border border-gray-800 shadow-2xl space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Full Name</label>
            <input 
              type="text" 
              placeholder="e.g. John Doe"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className={`w-full bg-[#0B0F14] border-2 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors ${errors.name ? 'border-red-500' : 'border-gray-800'}`}
            />
            {errors.name && <p className="text-red-500 text-xs font-bold">{errors.name}</p>}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Student ID</label>
            <input 
              type="text" 
              placeholder="e.g. TP012345"
              value={formData.studentId}
              onChange={(e) => setFormData({...formData, studentId: e.target.value})}
              className={`w-full bg-[#0B0F14] border-2 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors ${errors.studentId ? 'border-red-500' : 'border-gray-800'}`}
            />
            {errors.studentId && <p className="text-red-500 text-xs font-bold">{errors.studentId}</p>}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Student Email</label>
          <input 
            type="email" 
            placeholder="e.g. tp012345@mail.apu.edu.my"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            className={`w-full bg-[#0B0F14] border-2 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors ${errors.email ? 'border-red-500' : 'border-gray-800'}`}
          />
          {errors.email && <p className="text-red-500 text-xs font-bold">{errors.email}</p>}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Select Sport</label>
          <select 
            value={formData.sport}
            onChange={(e) => setFormData({...formData, sport: e.target.value})}
            className={`w-full bg-[#0B0F14] border-2 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors appearance-none ${errors.sport ? 'border-red-500' : 'border-gray-800'}`}
          >
            <option value="">-- Choose Category --</option>
            <option value="football">Football League</option>
            <option value="basketball">Basketball 5v5</option>
            <option value="badminton">Badminton Singles</option>
            <option value="esports">Valorant E-Sports</option>
            <option value="tkd">Taekwondo Sparring</option>
          </select>
          {errors.sport && <p className="text-red-500 text-xs font-bold">{errors.sport}</p>}
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <button 
            type="submit" 
            className="flex-1 bg-[#C6FF00] text-black font-black py-4 rounded-xl hover:shadow-[0_0_20px_rgba(198,255,0,0.4)] transition-all"
          >
            SUBMIT REGISTRATION
          </button>
          <button 
            type="button" 
            onClick={resetForm}
            className="px-8 py-4 border-2 border-gray-700 text-gray-400 font-bold rounded-xl hover:border-white hover:text-white transition-all"
          >
            RESET
          </button>
        </div>
      </form>
    </div>
  );
};

export default Registration;
