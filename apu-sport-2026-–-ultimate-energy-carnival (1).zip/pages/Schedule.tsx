
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SCHEDULE_DATA } from '../constants';
import { ScheduleItem } from '../types';

const Schedule: React.FC = () => {
  const [activeDay, setActiveDay] = useState(1);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [reminders, setReminders] = useState<Set<string>>(new Set());

  const days = [1, 2, 3];
  const categories = ['All', 'Ceremony', 'Tournament', 'Workshop', 'Finals'];

  const filteredSchedule = useMemo(() => {
    return SCHEDULE_DATA.filter(item => {
      const matchesDay = item.day === activeDay;
      const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
      const matchesSearch = item.event.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            item.location.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesDay && matchesCategory && matchesSearch;
    });
  }, [activeDay, activeCategory, searchQuery]);

  const toggleReminder = (id: string) => {
    const newReminders = new Set(reminders);
    if (newReminders.has(id)) {
      newReminders.delete(id);
    } else {
      newReminders.add(id);
    }
    setReminders(newReminders);
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Ceremony': return 'text-purple-400 bg-purple-400/10 border-purple-400/20';
      case 'Tournament': return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
      case 'Workshop': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'Finals': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  return (
    <div className="px-6 py-20 max-w-6xl mx-auto min-h-screen">
      <div className="mb-16 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter">EVENT<br/><span className="text-[#C6FF00]">TIMETABLE</span></h1>
            <p className="text-gray-400 max-w-md">Your interactive guide to the 3-day APU Energy Carnival. Filter by day, category, or search for specific events.</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative group w-full md:w-72"
          >
            <input 
              type="text"
              placeholder="Search events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#12181f] border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-600 focus:outline-none focus:border-[#C6FF00] transition-all"
            />
            <svg className="w-5 h-5 absolute right-6 top-1/2 -translate-y-1/2 text-gray-600 group-focus-within:text-[#C6FF00] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
          </motion.div>
        </div>

        <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
          {/* Day Tabs */}
          <div className="flex p-1.5 bg-[#12181f] rounded-2xl border border-gray-800 w-full md:w-auto">
            {days.map((day) => (
              <button
                key={day}
                onClick={() => setActiveDay(day)}
                className={`flex-1 md:flex-none px-8 py-3 rounded-xl font-black text-xs tracking-widest transition-all relative overflow-hidden ${
                  activeDay === day ? 'text-black' : 'text-gray-500 hover:text-white'
                }`}
              >
                {activeDay === day && (
                  <motion.div 
                    layoutId="activeDay"
                    className="absolute inset-0 bg-[#C6FF00]"
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <span className="relative z-10">DAY 0{day}</span>
              </button>
            ))}
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                  activeCategory === cat 
                    ? 'bg-[#C6FF00] text-black border-[#C6FF00]' 
                    : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Schedule List */}
      <div className="relative">
        <div className="absolute left-8 md:left-12 top-0 bottom-0 w-px bg-gradient-to-b from-[#C6FF00]/50 via-gray-800 to-transparent"></div>
        
        <div className="space-y-8 relative z-10">
          <AnimatePresence mode="popLayout">
            {filteredSchedule.length > 0 ? (
              filteredSchedule.map((item, idx) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: idx * 0.05 }}
                  className="group flex items-start gap-8 md:gap-12"
                >
                  {/* Time Column */}
                  <div className="flex flex-col items-center pt-2">
                    <div className="w-4 h-4 rounded-full bg-[#C6FF00] border-4 border-[#0B0F14] shadow-[0_0_10px_rgba(198,255,0,0.5)] group-hover:scale-125 transition-transform"></div>
                    <div className="mt-4 text-[#C6FF00] font-black text-sm whitespace-nowrap tracking-tighter">
                      {item.time}
                    </div>
                  </div>

                  {/* Card */}
                  <div className="flex-grow bg-[#12181f] border border-gray-800 rounded-[32px] p-6 md:p-8 hover:border-[#C6FF00]/30 transition-all hover:bg-[#161d26] relative overflow-hidden">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="space-y-2">
                        <div className={`inline-block px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.2em] border ${getCategoryColor(item.category)}`}>
                          {item.category}
                        </div>
                        <h3 className="text-xl md:text-2xl font-bold text-white group-hover:text-[#C6FF00] transition-colors">
                          {item.event}
                        </h3>
                        <div className="flex items-center text-gray-500 text-xs font-medium">
                          <svg className="w-4 h-4 mr-2 text-[#C6FF00]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                          </svg>
                          {item.location}
                        </div>
                      </div>

                      <button 
                        onClick={() => toggleReminder(item.id)}
                        className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                          reminders.has(item.id)
                            ? 'bg-[#C6FF00] text-black border-[#C6FF00]'
                            : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'
                        }`}
                      >
                        {reminders.has(item.id) ? 'SAVED' : 'REMIND ME'}
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20 bg-[#12181f] rounded-[40px] border border-dashed border-gray-800"
              >
                <div className="text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-bold text-white mb-2">No events found</h3>
                <p className="text-gray-500">Try adjusting your filters or search query.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Schedule;
