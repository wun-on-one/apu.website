
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { SPORTS_DATA } from '../constants';
import { Sport } from '../types';

const Sports: React.FC = () => {
  const [filter, setFilter] = useState<string>('All');
  const categories = ['All', 'Outdoor', 'Indoor', 'Competitive', 'Workshop'];

  const filteredSports = filter === 'All' 
    ? SPORTS_DATA 
    : SPORTS_DATA.filter(s => s.category === filter);

  return (
    <div className="px-6 py-20 max-w-7xl mx-auto">
      <div className="mb-16 text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-4">SPORTS OVERVIEW</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">From high-intensity physical competitions to strategic workshops, find the perfect event for your skills.</p>
      </div>

      {/* Filter System */}
      <div className="flex flex-wrap justify-center gap-4 mb-16">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-6 py-2 rounded-full font-bold transition-all ${
              filter === cat 
                ? 'bg-[#C6FF00] text-black shadow-[0_0_15px_rgba(198,255,0,0.5)]' 
                : 'bg-white/5 text-gray-400 hover:text-white border border-gray-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Sports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredSports.map((sport) => (
          <div key={sport.id} className="bg-[#12181f] rounded-[20px] overflow-hidden border border-gray-800 hover:border-[#C6FF00] transition-all group">
            <div className="relative h-48 overflow-hidden">
              <img 
                src={sport.image} 
                alt={sport.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute top-4 left-4 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-[10px] text-[#C6FF00] font-bold border border-[#C6FF00]/30 uppercase tracking-widest">
                {sport.category}
              </div>
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-black mb-3 text-white">{sport.name}</h3>
              <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                {sport.description}
              </p>
              <Link 
                to={sport.link} 
                className="inline-flex items-center text-[#C6FF00] font-bold hover:translate-x-2 transition-transform"
              >
                LEARN MORE 
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sports;
