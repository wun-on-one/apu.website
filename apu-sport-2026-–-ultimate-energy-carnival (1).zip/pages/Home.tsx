import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CountdownTimer = () => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const targetDate = new Date('August 1, 2026 00:00:00').getTime();
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000),
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const TimeUnit = ({ value, label }: { value: number, label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4 md:p-6 w-16 md:w-24 flex items-center justify-center">
        <span className="text-2xl md:text-4xl font-black text-[#C6FF00]">{value.toString().padStart(2, '0')}</span>
      </div>
      <span className="text-[10px] md:text-xs text-gray-500 mt-2 uppercase font-black tracking-widest">{label}</span>
    </div>
  );

  return (
    <div className="flex space-x-3 md:space-x-6">
      <TimeUnit value={timeLeft.days} label="Days" />
      <TimeUnit value={timeLeft.hours} label="Hours" />
      <TimeUnit value={timeLeft.minutes} label="Mins" />
      <TimeUnit value={timeLeft.seconds} label="Secs" />
    </div>
  );
};

const Home: React.FC = () => {
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 pt-20 relative overflow-hidden">
        
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl aspect-square bg-[#C6FF00]/10 rounded-full blur-[140px] -z-10"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <div className="inline-block px-4 py-1.5 border border-[#C6FF00]/30 rounded-full text-[#C6FF00] text-[10px] font-black tracking-[0.3em] uppercase mb-8 animate-pulse bg-[#C6FF00]/10">
            2026 APU ENERGY CARNIVAL
          </div>
          
          <h1 className="text-6xl md:text-9xl font-black mb-8 leading-none tracking-tighter">
            ONE APU.<br/>
            <span className="text-[#C6FF00] neon-glow">ONE SPIRIT.</span><br/>
            NO LIMITS.
          </h1>
          
          <p className="text-gray-400 text-base md:text-lg max-w-2xl mb-12 font-medium leading-relaxed">
            The transformation begins at the TPM Campus. 16+ sports, elite athletes, and 3 days of pure adrenaline at Technology Park Malaysia.
          </p>

          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6 mb-20">
            <Link 
              to="/sports" 
              className="px-10 py-4 bg-[#C6FF00] text-black font-black rounded-full hover:scale-105 transition-transform shadow-[0_0_20px_rgba(198,255,0,0.6)] uppercase tracking-widest text-sm"
            >
              DISCOVER SPORTS
            </Link>
            <Link 
              to="/registration" 
              className="px-10 py-4 border-2 border-white/20 text-white font-black rounded-full hover:bg-white hover:text-black transition-all uppercase tracking-widest text-sm backdrop-blur-sm"
            >
              REGISTER NOW
            </Link>
          </div>

          <CountdownTimer />
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6 max-w-7xl mx-auto relative">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
          {[
            { label: 'Athletes', value: '2500+' },
            { label: 'Sports', value: '16+' },
            { label: 'Prizes', value: '$50K' },
            { label: 'Volunteers', value: '300+' }
          ].map((stat, idx) => (
            <div key={idx} className="text-center p-8 rounded-3xl bg-white/[0.03] backdrop-blur-sm border border-white/10 hover:border-[#C6FF00]/60 transition-all group overflow-hidden relative">
              <div className="relative z-20">
                <div className="text-3xl md:text-5xl font-black text-white mb-2 group-hover:text-[#C6FF00] transition-colors">{stat.value}</div>
                <div className="text-gray-500 uppercase font-black tracking-widest text-[10px]">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
