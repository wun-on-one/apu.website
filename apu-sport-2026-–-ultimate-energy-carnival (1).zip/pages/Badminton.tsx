
import React from 'react';
import { Link } from 'react-router-dom';

const Badminton: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="flex flex-col md:flex-row items-center gap-16">
        <div className="flex-1">
          <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight">BADMINTON<br/><span className="text-[#C6FF00]">SHUTTLE CLASH</span></h1>
          <p className="text-gray-400 text-lg mb-8">Fast reflections, heavy smashes. Join the most popular indoor sport at APU. Open for Men's & Women's Singles and Doubles.</p>
          <div className="flex space-x-6">
            <div className="text-center">
              <div className="text-3xl font-black text-white">32</div>
              <div className="text-xs text-gray-500 uppercase">Total Slots</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-black text-white">YONEX</div>
              <div className="text-xs text-gray-500 uppercase">Official Gear</div>
            </div>
          </div>
        </div>
        <div className="flex-1 grid grid-cols-2 gap-4">
          <img src="https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&q=80&w=400" className="rounded-3xl h-64 w-full object-cover" />
          <img src="https://images.unsplash.com/photo-1613918431703-018659f13904?auto=format&fit=crop&q=80&w=400" className="rounded-3xl h-64 w-full object-cover mt-12" />
        </div>
      </div>

      <div className="p-12 bg-[#12181f] rounded-[40px] border border-gray-800 text-center max-w-3xl mx-auto">
        <h2 className="text-2xl font-black mb-4 uppercase">Tournament Details</h2>
        <p className="text-gray-400 mb-8">Venue: APU Sports Center (Level 4). Knockout elimination format. 21-point rally scoring system.</p>
        <Link to="/registration" className="inline-block px-12 py-5 bg-[#C6FF00] text-black font-black rounded-2xl hover:scale-105 transition-all shadow-[0_0_20px_rgba(198,255,0,0.3)]">
          APPLY FOR CLASH
        </Link>
      </div>
    </div>
  );
};

export default Badminton;
