
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const About: React.FC = () => {
  const stats = [
    { label: 'Active Clubs', value: '25+' },
    { label: 'Annual Events', value: '50+' },
    { label: 'Medals Won', value: '150+' },
    { label: 'Student Athletes', value: '1,200+' },
  ];

  const committee = [
    { name: 'Dr. Hari Narayanan', role: 'President of Sports Council', image: 'https://picsum.photos/seed/apu1/200' },
    { name: 'Sarah Jenkins', role: 'Head of Sports Development', image: 'https://picsum.photos/seed/apu2/200' },
    { name: 'Marcus Chen', role: 'Logistics Director', image: 'https://picsum.photos/seed/apu3/200' },
    { name: 'Elena Rodriguez', role: 'Student Affairs Lead', image: 'https://picsum.photos/seed/apu4/200' },
    { name: 'David Lim', role: 'Technical Coordinator', image: 'https://picsum.photos/seed/apu5/200' },
    { name: 'Aisha Malik', role: 'Marketing & PR Manager', image: 'https://picsum.photos/seed/apu6/200' },
    { name: 'Kevin Wong', role: 'Events Manager', image: 'https://picsum.photos/seed/apu7/200' },
    { name: 'Priya Das', role: 'Athlete Welfare Officer', image: 'https://picsum.photos/seed/apu8/200' },
  ];

  const facilities = [
    { 
      title: 'TPM Complex', 
      desc: 'Our primary hub featuring a high-performance gym, 12 badminton courts, and multi-purpose indoor arenas.',
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800'
    },
    { 
      title: 'Aquatic Center', 
      desc: 'An Olympic-sized swimming pool equipped with advanced timing systems for competitive training.',
      image: 'https://images.unsplash.com/photo-1519315901367-f34ff9154487?auto=format&fit=crop&q=80&w=800'
    },
    { 
      title: 'Outdoor Arena', 
      desc: 'Floodlit futsal courts, a full-sized football pitch, and dedicated zones for rugby and frisbee.',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&q=80&w=800'
    }
  ];

  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-40 overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-6xl md:text-8xl font-black mb-8 leading-[0.9] uppercase tracking-tighter">
              THE HEART OF<br/>
              <span className="text-[#C6FF00]">APU ENERGY</span>
            </h1>
            <p className="text-gray-400 text-xl mb-10 leading-relaxed max-w-xl">
              Asia Pacific University (APU) is more than just a center for technology; it's a powerhouse of athletic talent. We believe in the synergy of mind and body, fostering a culture where innovation meets physical excellence.
            </p>
            <div className="flex gap-12">
              <div>
                <h4 className="text-[#C6FF00] font-black text-xs uppercase tracking-[0.2em] mb-3">Our Mission</h4>
                <p className="text-gray-500 text-sm leading-relaxed">Empowering students through elite sports infrastructure and competitive platforms.</p>
              </div>
              <div>
                <h4 className="text-[#C6FF00] font-black text-xs uppercase tracking-[0.2em] mb-3">Our Vision</h4>
                <p className="text-gray-500 text-sm leading-relaxed">Setting the global standard for technology-integrated university sports.</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, type: 'spring' }}
            className="relative"
          >
            <div className="absolute inset-0 bg-[#C6FF00] blur-[120px] opacity-20 rounded-full"></div>
            <div className="relative aspect-square rounded-[60px] overflow-hidden border border-gray-800 shadow-2xl z-10 transform hover:scale-[1.02] transition-transform duration-700">
              <img src="https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover" alt="APU Sports" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-8">
        {stats.map((stat, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="text-center p-10 bg-[#12181f] rounded-[40px] border border-gray-800 hover:border-[#C6FF00]/30 transition-all"
          >
            <div className="text-5xl md:text-6xl font-black text-[#C6FF00] mb-2 tracking-tighter">{stat.value}</div>
            <div className="text-gray-500 text-xs uppercase font-bold tracking-widest">{stat.label}</div>
          </motion.div>
        ))}
      </section>

      {/* Facilities Section */}
      <section className="space-y-16">
        <div className="text-center space-y-4">
          <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">ELITE INFRASTRUCTURE</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">Our facilities at Technology Park Malaysia (TPM) are designed to support athletes at every level, from recreational play to professional training.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {facilities.map((facility, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="group bg-[#12181f] rounded-[40px] overflow-hidden border border-gray-800 hover:border-[#C6FF00]/50 transition-all"
            >
              <div className="h-64 overflow-hidden">
                <img src={facility.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={facility.title} />
              </div>
              <div className="p-10 space-y-4">
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">{facility.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{facility.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* History Timeline */}
      <section className="relative">
        <div className="text-center mb-24">
          <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">HALL OF FAME</h2>
          <p className="text-gray-500 mt-4">A legacy of victory and sportsmanship.</p>
        </div>
        
        <div className="relative space-y-24 before:absolute before:inset-0 before:left-8 md:before:left-1/2 before:-ml-px before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-[#C6FF00] before:to-transparent">
          {[
            { year: '2022', title: 'Wushu & Swimming', desc: 'APU athletes secured 12 gold medals at the National Inter-University Games, setting three new records in swimming.' },
            { year: '2024', title: 'Basketball & Frisbee', desc: 'The Men\'s Basketball team dominated UBL 2024, while Team Pixel Frisbee won Pool B at the Nottingham Battle Royale.' },
            { year: '2025', title: 'Volleyball Success', desc: 'Our Men\'s Volleyball team secured the second runner-up position at the prestigious MASISWA Sports Championship.' },
            { year: '2026', title: 'The Energy Carnival', desc: 'Launching our most ambitious sports festival yet, with 16+ sports and 2,000+ participants.' }
          ].map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className={`relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group`}
            >
              <div className="flex items-center justify-center w-20 h-20 rounded-full border-4 border-[#0B0F14] bg-[#12181f] text-[#C6FF00] font-black z-10 absolute left-0 md:left-1/2 md:-ml-10 group-hover:bg-[#C6FF00] group-hover:text-black transition-all duration-500 shadow-[0_0_20px_rgba(198,255,0,0.2)]">
                {item.year}
              </div>
              <div className="w-full md:w-[42%] bg-[#12181f] p-10 rounded-[40px] border border-gray-800 ml-24 md:ml-0 relative overflow-hidden hover:border-[#C6FF00]/30 transition-all">
                <h3 className="text-2xl font-black mb-3 text-white uppercase tracking-tight">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Committee */}
      <section className="space-y-20">
        <div className="text-center">
          <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">ORGANIZING COMMITTEE</h2>
          <p className="text-gray-500 mt-4">The dedicated team behind the APU Energy Carnival.</p>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {committee.map((member, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              className="bg-[#12181f] p-10 rounded-[40px] border border-gray-800 hover:border-[#C6FF00]/50 transition-all text-center group"
            >
              <div className="w-24 h-24 bg-gray-800 rounded-full mx-auto mb-6 overflow-hidden border-2 border-transparent group-hover:border-[#C6FF00] transition-all">
                <img src={member.image} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" alt={member.name} />
              </div>
              <h4 className="text-white font-black text-sm mb-1 uppercase tracking-tight">{member.name}</h4>
              <span className="text-[10px] text-[#C6FF00] font-black uppercase tracking-widest">{member.role}</span>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="bg-[#C6FF00] p-16 md:p-24 rounded-[60px] text-black text-center space-y-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-black/5 rounded-full -mr-32 -mt-32"></div>
          <div className="relative z-10">
            <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-none mb-6">BE PART OF THE<br/>LEGACY</h2>
            <p className="text-black/70 font-bold max-w-xl mx-auto mb-10">Join the ranks of APU's finest athletes. Whether you're a seasoned pro or a passionate beginner, there's a place for you.</p>
            <Link 
              to="/registration"
              className="inline-block px-12 py-5 bg-black text-[#C6FF00] font-black rounded-full hover:scale-105 transition-transform uppercase tracking-widest text-sm"
            >
              Register Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
