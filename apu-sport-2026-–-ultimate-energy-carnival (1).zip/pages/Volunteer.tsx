
import React from 'react';

const Volunteer: React.FC = () => {
  return (
    <div className="px-6 py-20 max-w-7xl mx-auto space-y-20">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">BE THE<br/><span className="text-[#C6FF00]">BACKBONE</span></h1>
        <p className="text-gray-400 max-w-xl mx-auto">Help us make history. Gain event management experience, earn merit points, and get exclusive 2026 crew merchandise.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <h2 className="text-2xl font-black uppercase text-[#C6FF00]">Choose Your Role</h2>
          <div className="space-y-4">
            {[
              { role: 'Field Marshal', desc: 'Manage athlete check-ins and court readiness.' },
              { role: 'Media Crew', desc: 'Assist in photography and live social updates.' },
              { role: 'Technical Support', desc: 'Handle scoreboard systems and equipment.' },
              { role: 'Guest Liaison', desc: 'Assist sponsors and VIP attendees.' }
            ].map((r, i) => (
              <div key={i} className="flex items-center p-6 bg-[#12181f] border border-gray-800 rounded-3xl hover:border-[#C6FF00] transition-colors cursor-pointer group">
                <div className="w-12 h-12 bg-[#0B0F14] rounded-2xl flex items-center justify-center mr-6 group-hover:bg-[#C6FF00] group-hover:text-black transition-all">
                  <span className="font-bold">{i+1}</span>
                </div>
                <div>
                  <h4 className="text-white font-bold mb-1 uppercase">{r.role}</h4>
                  <p className="text-gray-500 text-xs">{r.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#12181f] p-10 md:p-16 rounded-[40px] border border-gray-800 flex flex-col justify-center">
          <h2 className="text-2xl font-black mb-8 text-center uppercase">Quick Apply</h2>
          <div className="space-y-6">
            <input type="text" placeholder="Full Name" className="w-full bg-[#0B0F14] border border-gray-800 rounded-xl p-4 text-white focus:border-[#C6FF00] outline-none" />
            <input type="email" placeholder="Student Email" className="w-full bg-[#0B0F14] border border-gray-800 rounded-xl p-4 text-white focus:border-[#C6FF00] outline-none" />
            <div className="p-4 bg-white/5 border border-gray-800 rounded-xl">
              <span className="text-xs font-bold text-gray-500 uppercase block mb-4">Availability Calendar</span>
              <div className="grid grid-cols-3 gap-2">
                {['Day 1', 'Day 2', 'Day 3'].map(d => (
                  <button key={d} className="py-3 border border-gray-700 rounded-lg text-xs font-bold hover:bg-[#C6FF00] hover:text-black transition-all">{d}</button>
                ))}
              </div>
            </div>
            <button className="w-full py-5 bg-[#C6FF00] text-black font-black rounded-xl shadow-[0_0_20px_rgba(198,255,0,0.3)]">SUBMIT APPLICATION</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Volunteer;
