
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formState.name && formState.email && formState.message) {
      setSent(true);
      setTimeout(() => setSent(false), 5000);
      setFormState({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className="px-6 py-20 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div>
          <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tighter">LET'S<br/><span className="text-[#C6FF00]">CONNECT</span></h1>
          <p className="text-gray-400 text-lg mb-12 max-w-md">Our committee is here to assist you. Whether you are a student, sponsor, or visitor, we want to hear from you.</p>
          
          <div className="space-y-8 mb-12">
            <div className="flex items-start space-x-6">
              <div className="w-12 h-12 bg-[#12181f] border border-gray-800 rounded-2xl flex items-center justify-center flex-shrink-0 text-[#C6FF00]">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Our Location</h4>
                <p className="text-gray-400 text-sm">Asia Pacific University (APU)<br/>Technology Park Malaysia, KL</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="w-12 h-12 bg-[#12181f] border border-gray-800 rounded-2xl flex items-center justify-center flex-shrink-0 text-[#C6FF00]">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">Email Inquiry</h4>
                <p className="text-gray-400 text-sm">sport2026@apu.edu.my<br/>info.carnival@apu.edu.my</p>
              </div>
            </div>
          </div>

          <div className="h-64 rounded-3xl overflow-hidden border border-gray-800 grayscale">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.14555776686!2d101.6978432!3d3.0560667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc36070a927a3d%3A0xc3438848d7c17046!2sAsia%20Pacific%20University%20of%20Technology%20%26%20Innovation%20(APU)!5e0!3m2!1sen!2smy!4v1700000000000!5m2!1sen!2smy"
              width="100%" height="100%" style={{ border: 0 }} allowFullScreen={true} loading="lazy"
            ></iframe>
          </div>
        </div>

        <div className="bg-[#12181f] p-10 md:p-16 rounded-[40px] border border-gray-800">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-500">Your Full Name</label>
              <input 
                type="text" 
                required
                value={formState.name}
                onChange={(e) => setFormState({...formState, name: e.target.value})}
                className="w-full bg-[#0B0F14] border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors"
                placeholder="John Student"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-500">Email Address</label>
              <input 
                type="email" 
                required
                value={formState.email}
                onChange={(e) => setFormState({...formState, email: e.target.value})}
                className="w-full bg-[#0B0F14] border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors"
                placeholder="email@example.com"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-500">Detailed Message</label>
              <textarea 
                rows={5} 
                required
                value={formState.message}
                onChange={(e) => setFormState({...formState, message: e.target.value})}
                className="w-full bg-[#0B0F14] border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:border-[#C6FF00] transition-colors resize-none"
                placeholder="How can we help you today?"
              ></textarea>
            </div>
            <button 
              type="submit" 
              className={`w-full py-5 rounded-xl font-black text-black transition-all ${sent ? 'bg-green-500' : 'bg-[#C6FF00] hover:shadow-[0_0_20px_rgba(198,255,0,0.4)]'}`}
            >
              {sent ? 'MESSAGE SENT!' : 'SEND INQUIRY'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
