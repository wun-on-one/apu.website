import React, { useState } from 'react';

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const images = Array.from({ length: 9 }).map((_, i) => ({
    id: i,
    url: `https://picsum.photos/seed/sport-${i}/800/600`,
    title: `Moment Highlight #${i + 1}`
  }));

  return (
    <div className="px-6 py-20 max-w-7xl mx-auto">
      <div className="mb-16 text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-4">MEMORIES IN MOTION</h1>
        <p className="text-gray-400">Captured moments from previous carnivals. Revisit the adrenaline.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((img) => (
          <div 
            key={img.id} 
            onClick={() => setSelectedImage(img.url)}
            className="aspect-[4/3] rounded-3xl overflow-hidden cursor-pointer group relative bg-[#12181f]"
          >
            <img 
              src={img.url} 
              alt={img.title} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80 group-hover:opacity-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8">
              <span className="text-[#C6FF00] font-black text-lg tracking-tight">{img.title}</span>
              <span className="text-gray-400 text-xs">VIEW FULLSIZE</span>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4 md:p-12 animate-in fade-in duration-300"
          onClick={() => setSelectedImage(null)}
        >
          <button className="absolute top-8 right-8 text-white hover:text-[#C6FF00]">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <img 
            src={selectedImage} 
            className="max-w-full max-h-full rounded-2xl shadow-2xl animate-in zoom-in duration-300" 
            alt="Large Preview"
            onClick={(e) => e.stopPropagation()} 
          />
        </div>
      )}

      {/* Video Highlight Reel */}
      <div className="mt-32">
        <h2 className="text-3xl font-black mb-12 text-center uppercase tracking-tighter">Event Teaser 2026</h2>
        <div className="aspect-video max-w-4xl mx-auto rounded-[40px] overflow-hidden border-8 border-[#12181f] shadow-2xl relative group">
          <img src="https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover" />
          
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-20">
            <button className="w-24 h-24 bg-[#C6FF00] rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(198,255,0,0.6)] hover:scale-110 transition-transform">
              <svg className="w-10 h-10 text-black fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gallery;