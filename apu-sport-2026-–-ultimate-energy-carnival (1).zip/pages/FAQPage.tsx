import React, { useState, useMemo, useEffect, useRef } from 'react';
import { FAQS } from '../constants';
import { FAQ } from '../types';

const CategoryIcons: Record<string, React.ReactNode> = {
  Registration: (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
    </svg>
  ),
  Schedule: (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>
  ),
  Rules: (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
  Prizes: (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5a2 2 0 10-2 2h2z" />
    </svg>
  ),
  Venue: (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
};

const HighlightText = ({ text, highlight }: { text: string; highlight: string }) => {
  if (!highlight.trim()) return <span>{text}</span>;
  const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === highlight.toLowerCase() ? (
          <span key={i} className="text-[#C6FF00] font-black underline underline-offset-2 decoration-[#C6FF00]/50 shadow-[0_0_10px_rgba(198,255,0,0.4)]">
            {part}
          </span>
        ) : (
          part
        )
      )}
    </span>
  );
};

// Use React.FC to allow 'key' prop and explicitly define prop types for FAQItem.
const FAQItem: React.FC<{ faq: FAQ; isOpen: boolean; onToggle: () => void; searchQuery: string }> = ({ faq, isOpen, onToggle, searchQuery }) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number | string>(0);

  useEffect(() => {
    if (isOpen) {
      setHeight(contentRef.current?.scrollHeight || 'auto');
    } else {
      setHeight(0);
    }
  }, [isOpen]);

  return (
    <div
      className={`group bg-[#12181f]/60 backdrop-blur-md border rounded-3xl overflow-hidden transition-all duration-500 mb-4 animate-reveal ${
        isOpen ? 'border-[#C6FF00] shadow-[0_0_20px_rgba(198,255,0,0.1)] scale-[1.02]' : 'border-gray-800 hover:border-gray-600'
      }`}
    >
      <button
        onClick={onToggle}
        className="w-full p-6 md:p-8 flex items-center justify-between text-left focus:outline-none"
      >
        <span className={`text-lg font-bold transition-colors duration-300 ${isOpen ? 'text-[#C6FF00]' : 'text-white'}`}>
          <HighlightText text={faq.question} highlight={searchQuery} />
        </span>
        <div className={`p-2 rounded-full border transition-all duration-500 ${isOpen ? 'bg-[#C6FF00] border-[#C6FF00] rotate-180' : 'bg-transparent border-gray-700 rotate-0'}`}>
          <svg className={`w-5 h-5 transition-colors ${isOpen ? 'text-black' : 'text-gray-500'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>
      <div
        ref={contentRef}
        style={{ height }}
        className="transition-all duration-500 ease-in-out"
      >
        <div className="px-8 pb-8">
          <div className="h-px bg-gray-800 mb-6 opacity-50"></div>
          <p className="text-gray-400 leading-relaxed text-base">
            <HighlightText text={faq.answer} highlight={searchQuery} />
          </p>
        </div>
      </div>
    </div>
  );
};

const FAQPage: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Search Logic
  const filteredFaqs = useMemo(() => {
    if (!searchQuery.trim()) return FAQS;
    return FAQS.filter(
      (f) =>
        f.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  // Use explicit return type for categorizedFaqs to ensure correct typing in Object.entries.
  const categorizedFaqs = useMemo<Record<string, FAQ[]>>(() => {
    const categories: Record<string, FAQ[]> = {};
    filteredFaqs.forEach((faq) => {
      if (!categories[faq.category]) categories[faq.category] = [];
      categories[faq.category].push(faq);
    });
    return categories;
  }, [filteredFaqs]);

  // Local Spider Background Effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let particles: { x: number; y: number; vx: number; vy: number }[] = [];
    const particleCount = 40;

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
      init();
    };

    const init = () => {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
        });
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = 'rgba(198, 255, 0, 0.05)';
      ctx.fillStyle = 'rgba(198, 255, 0, 0.1)';

      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.sqrt((p.x - p2.x) ** 2 + (p.y - p2.y) ** 2);
          if (dist < 150) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      });
      animationId = requestAnimationFrame(draw);
    };

    window.addEventListener('resize', resize);
    resize();
    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="relative min-h-screen px-6 py-32 overflow-hidden">
      {/* Local Background Layer */}
      <canvas ref={canvasRef} className="absolute inset-0 -z-10 pointer-events-none opacity-40" />
      
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="mb-16 text-center animate-reveal">
          <div className="inline-block px-4 py-1.5 border border-[#C6FF00]/30 rounded-full text-[#C6FF00] text-[10px] font-black tracking-[0.3em] uppercase mb-6 bg-[#C6FF00]/5">
            Support Center
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-6 uppercase tracking-tighter leading-none">
            FREQUENTLY ASKED <br/><span className="text-[#C6FF00] neon-glow">QUESTIONS</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-xl mx-auto font-medium">
            Find answers to common inquiries about the APU Sport 2026 Energy Carnival.
          </p>
        </div>

        {/* Enhanced Search Bar */}
        <div className="mb-16 relative group animate-reveal delay-100">
          <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
            <svg className="w-6 h-6 text-gray-500 group-focus-within:text-[#C6FF00] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <input
            type="text"
            placeholder="Search questions, categories, or keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#12181f]/80 backdrop-blur-xl border-2 border-gray-800 rounded-[30px] py-6 pl-16 pr-6 text-white text-lg placeholder-gray-500 focus:outline-none focus:border-[#C6FF00] focus:shadow-[0_0_30px_rgba(198,255,0,0.15)] transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-6 flex items-center text-gray-500 hover:text-white"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Results Message */}
        {Object.keys(categorizedFaqs).length === 0 && (
          <div className="text-center py-20 bg-[#12181f]/40 rounded-[40px] border border-dashed border-gray-800 animate-reveal">
            <div className="w-16 h-16 bg-gray-800/50 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-500">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 9.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-400 mb-2">NO RESULTS FOUND</h3>
            <p className="text-gray-500">Try adjusting your search or contact our support team directly.</p>
          </div>
        )}

        {/* FAQ List Grouped by Categories */}
        {(Object.entries(categorizedFaqs) as [string, FAQ[]][]).map(([category, items], idx) => (
          <div key={category} className="mb-12 animate-reveal" style={{ animationDelay: `${idx * 150}ms` }}>
            <div className="flex items-center space-x-4 mb-8">
              <div className="p-3 bg-[#C6FF00]/10 rounded-2xl text-[#C6FF00] shadow-[0_0_15px_rgba(198,255,0,0.1)]">
                {CategoryIcons[category] || CategoryIcons['Rules']}
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white">{category}</h2>
            </div>
            <div>
              {items.map((faq) => (
                <FAQItem
                  key={faq.id}
                  faq={faq}
                  searchQuery={searchQuery}
                  isOpen={openId === faq.id}
                  onToggle={() => setOpenId(openId === faq.id ? null : faq.id)}
                />
              ))}
            </div>
          </div>
        ))}

        {/* Final CTA */}
        <div className="mt-24 p-12 bg-gradient-to-br from-[#12181f] to-[#0B0F14] rounded-[50px] border border-gray-800 text-center relative overflow-hidden animate-reveal">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#C6FF00]/5 rounded-full blur-[80px] -z-10"></div>
          <h3 className="text-3xl font-black mb-6 uppercase tracking-tighter text-white">STILL CURIOUS?</h3>
          <p className="text-gray-400 mb-10 text-lg max-w-md mx-auto">
            If your question isn't answered above, feel free to reach out to our dedicated support team.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-10 py-5 bg-[#C6FF00] text-black font-black rounded-2xl hover:scale-105 transition-all shadow-[0_0_25px_rgba(198,255,0,0.3)] uppercase tracking-widest text-sm">
              Contact Support
            </button>
            <button className="px-10 py-5 border-2 border-white/10 text-white font-bold rounded-2xl hover:bg-white hover:text-black transition-all uppercase tracking-widest text-sm backdrop-blur-sm">
              Live Chat
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;