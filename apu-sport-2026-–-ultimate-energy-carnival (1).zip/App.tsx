import React, { useState, useEffect, useRef } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { NAV_LINKS } from './constants';
import Home from './pages/Home';
import About from './pages/About';
import Sports from './pages/Sports';
import Schedule from './pages/Schedule';
import Registration from './pages/Registration';
import Volunteer from './pages/Volunteer';
import Gallery from './pages/Gallery';
import News from './pages/News';
import FAQPage from './pages/FAQPage';
import Contact from './pages/Contact';
import Football from './pages/Football';
import Basketball from './pages/Basketball';
import Taekwondo from './pages/Taekwondo';
import Badminton from './pages/Badminton';
import Esports from './pages/Esports';
import Volleyball from './pages/Volleyball';
import Futsal from './pages/Futsal';
import Frisbee from './pages/Frisbee';
import Rugby from './pages/Rugby';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const PageWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
  >
    {children}
  </motion.div>
);

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className="fixed top-0 w-full z-50 glass-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center space-x-2">
              <div className="w-10 h-10 bg-[#C6FF00] rounded-full flex items-center justify-center font-black text-black text-xs">APU</div>
              <span className="text-[#C6FF00] font-black text-xl tracking-tighter">SPORT 2026</span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-1 py-2 rounded-md text-xs font-bold uppercase tracking-widest transition-colors ${
                    location.pathname === link.path ? 'text-[#C6FF00]' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-[#0B0F14] border-b border-gray-800">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-gray-700"
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

const Footer = () => (
  <footer className="bg-[#05080b] py-16 px-6 border-t border-gray-800 relative overflow-hidden">
    <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 text-center md:text-left relative z-20">
      <div>
        <h3 className="text-[#C6FF00] font-bold text-lg mb-4">APU SPORT 2026</h3>
        <p className="text-gray-400 text-sm">Empowering the next generation of champions. Join the energy carnival and witness the transformation.</p>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Quick Links</h4>
        <ul className="space-y-2 text-sm text-gray-400">
          <li><Link to="/about" className="hover:text-[#C6FF00]">Event Objectives</Link></li>
          <li><Link to="/sports" className="hover:text-[#C6FF00]">Sport Categories</Link></li>
          <li><Link to="/registration" className="hover:text-[#C6FF00]">Register Now</Link></li>
          <li><Link to="/schedule" className="hover:text-[#C6FF00]">Daily Schedule</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Community</h4>
        <ul className="space-y-2 text-sm text-gray-400">
          <li><Link to="/volunteer" className="hover:text-[#C6FF00]">Become a Volunteer</Link></li>
          <li><Link to="/gallery" className="hover:text-[#C6FF00]">Photo Highlights</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-semibold mb-4">Contact</h4>
        <p className="text-gray-400 text-sm">Technology Park Malaysia,<br/>Bukit Jalil, Kuala Lumpur</p>
      </div>
    </div>
    <div className="text-center mt-12 pt-8 border-t border-gray-900 text-gray-600 text-xs relative z-20">
      &copy; 2026 APU Sport Management. All Rights Reserved.
    </div>
  </footer>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location}>
        <Route path="/" element={<PageWrapper><Home /></PageWrapper>} />
        <Route path="/about" element={<PageWrapper><About /></PageWrapper>} />
        <Route path="/sports" element={<PageWrapper><Sports /></PageWrapper>} />
        <Route path="/football" element={<PageWrapper><Football /></PageWrapper>} />
        <Route path="/basketball" element={<PageWrapper><Basketball /></PageWrapper>} />
        <Route path="/taekwondo" element={<PageWrapper><Taekwondo /></PageWrapper>} />
        <Route path="/badminton" element={<PageWrapper><Badminton /></PageWrapper>} />
        <Route path="/esports" element={<PageWrapper><Esports /></PageWrapper>} />
        <Route path="/volleyball" element={<PageWrapper><Volleyball /></PageWrapper>} />
        <Route path="/futsal" element={<PageWrapper><Futsal /></PageWrapper>} />
        <Route path="/frisbee" element={<PageWrapper><Frisbee /></PageWrapper>} />
        <Route path="/rugby" element={<PageWrapper><Rugby /></PageWrapper>} />
        <Route path="/schedule" element={<PageWrapper><Schedule /></PageWrapper>} />
        <Route path="/registration" element={<PageWrapper><Registration /></PageWrapper>} />
        <Route path="/volunteer" element={<PageWrapper><Volunteer /></PageWrapper>} />
        <Route path="/gallery" element={<PageWrapper><Gallery /></PageWrapper>} />
        <Route path="/news" element={<PageWrapper><News /></PageWrapper>} />
        <Route path="/faq" element={<PageWrapper><FAQPage /></PageWrapper>} />
        <Route path="/contact" element={<PageWrapper><Contact /></PageWrapper>} />
      </Routes>
    </AnimatePresence>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-transparent relative">
        <Navbar />
        <main className="flex-grow">
          <AnimatedRoutes />
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
